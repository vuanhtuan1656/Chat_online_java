﻿USE chatonline
go
-- Kiểm tra xem đã có constraint chưa
SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
WHERE TABLE_NAME = 'TaiKhoan' AND CONSTRAINT_TYPE = 'UNIQUE';

-- Nếu chưa có, thêm constraint
ALTER TABLE dbo.TaiKhoan 
ADD CONSTRAINT UQ_Username UNIQUE (username);