/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package client;

import javax.swing.JDialog;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.function.Consumer;

/**
 *
 * @author Toan PC
 */
public class ServerSelectionDialog extends JDialog {
      private DefaultListModel<String> listModel;
    private JList<String> serverList;
    private boolean connected = false;
    private String username;
    private String password;
    private String fullName;
    private boolean isRegister;
    private Consumer<Boolean> registerCallback; // THAY ĐỔI: Dùng Consumer thay vì RegisterResult
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ServerSelectionDialog.class.getName());

    // THAY ĐỔI: Constructor nhận Consumer<Boolean> thay vì LoginFrame.RegisterResult
    public ServerSelectionDialog(JFrame parent, String username, String password, String fullName, boolean isRegister, Consumer<Boolean> callback) {
        super(parent, "Chọn server", true);
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.isRegister = isRegister;
        this.registerCallback = callback;
        initSeverComponents();
    }

    private void initSeverComponents() {
        setSize(500, 450);
        setLocationRelativeTo(getOwner());

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Danh sách server", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        listModel = new DefaultListModel<>();
        loadServers();
        
        serverList = new JList<>(listModel);
        serverList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        serverList.setFont(new Font("Monospaced", Font.PLAIN, 13));
        serverList.setCellRenderer(new ServerListRenderer());
        
        JScrollPane scrollPane = new JScrollPane(serverList);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton addButton = new JButton("Thêm");
        addButton.addActionListener(e -> addServer());

        JButton removeButton = new JButton("Xoá");
        removeButton.addActionListener(e -> removeServer());

        JButton editButton = new JButton("Sửa");
        editButton.addActionListener(e -> editServer());

        JButton connectButton = new JButton("Truy cập");
        connectButton.setBackground(new Color(51, 122, 183));
        connectButton.setForeground(Color.BLUE);
        connectButton.addActionListener(e -> connectToServer());

        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(editButton);
        buttonPanel.add(connectButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private void loadServers() {
        listModel.clear();
        File file = new File("config.txt");
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    listModel.addElement(line.trim());
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Không thể đọc file config.txt");
        }
    }

    private void saveServers() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("config.txt"))) {
            for (int i = 0; i < listModel.size(); i++) {
                pw.println(listModel.get(i));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Không thể lưu file config.txt");
        }
    }

    private void addServer() {
        String input = JOptionPane.showInputDialog(this, "Nhập địa chỉ server (host:port):", "localhost:3000");
        if (input != null && !input.trim().isEmpty()) {
            if (input.matches(".+:\\d+")) {
                listModel.addElement(input.trim());
                saveServers();
            } else {
                JOptionPane.showMessageDialog(this, "Định dạng không hợp lệ! Vui lòng nhập theo định dạng host:port");
            }
        }
    }

    private void removeServer() {
        int selected = serverList.getSelectedIndex();
        if (selected != -1) {
            listModel.remove(selected);
            saveServers();
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn server cần xóa!");
        }
    }

    private void editServer() {
        int selected = serverList.getSelectedIndex();
        if (selected != -1) {
            String current = listModel.get(selected);
            String input = JOptionPane.showInputDialog(this, "Sửa địa chỉ server:", current);
            if (input != null && !input.trim().isEmpty()) {
                if (input.matches(".+:\\d+")) {
                    listModel.set(selected, input.trim());
                    saveServers();
                } else {
                    JOptionPane.showMessageDialog(this, "Định dạng không hợp lệ!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn server cần sửa!");
        }
    }

    // THAY ĐỔI: Cập nhật phần xử lý kết nối
    private void connectToServer() {
        String selected = serverList.getSelectedValue();
        if (selected != null) {
            String[] parts = selected.split(":");
            if (parts.length == 2) {
                String host = parts[0];
                int port = Integer.parseInt(parts[1]);
                
                JDialog connectingDialog = new JDialog(this, "Đang kết nối...", false);
                JPanel panel = new JPanel(new BorderLayout(10, 10));
                panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                panel.add(new JLabel("Đang kết nối tới " + host + ":" + port + "...", SwingConstants.CENTER), BorderLayout.CENTER);
                JProgressBar progressBar = new JProgressBar();
                progressBar.setIndeterminate(true);
                panel.add(progressBar, BorderLayout.SOUTH);
                connectingDialog.add(panel);
                connectingDialog.setSize(350, 120);
                connectingDialog.setLocationRelativeTo(this);
                connectingDialog.setVisible(true);
                
                new Thread(() -> {
                    ChatWindow chatWindow = null;
                    try {
                        chatWindow = new ChatWindow(host, port, username, password, fullName, isRegister);
                        final ChatWindow finalChatWindow = chatWindow;
                        
                        // Đợi server phản hồi
                        Thread.sleep(2000);
                        
                        // THAY ĐỔI: Kiểm tra xem ChatWindow có bị đóng không (do lỗi register)
                        if (!chatWindow.isDisplayable() && isRegister) {
                            // ChatWindow đã bị đóng = có lỗi từ server
                            throw new RuntimeException("Đăng ký thất bại");
                        }
                        
                        connected = true;
                        
                        SwingUtilities.invokeLater(() -> {
                            connectingDialog.dispose();
                            dispose();
                            
                            // Báo thành công nếu là register
                            if (isRegister && registerCallback != null) {
                                registerCallback.accept(true);
                            }
                        });
                    } catch (Exception e) {
                        final ChatWindow finalChatWindow = chatWindow;
                        
                        SwingUtilities.invokeLater(() -> {
                            connectingDialog.dispose();
                            
                            // Đóng ChatWindow nếu nó đã được tạo
                            if (finalChatWindow != null) {
                                try {
                                    finalChatWindow.dispose();
                                } catch (Exception ex) {
                                    // Ignore
                                }
                            }
                            
                            String errorMsg = e.getMessage();
                            logger.info("Error connecting: " + errorMsg);
                            
                            // Nếu là register, luôn báo lỗi về LoginFrame
                            if (isRegister && registerCallback != null) {
                                logger.info("=== CALLING CALLBACK with FALSE ===");
                                // Đóng dialog này
                                dispose();
                                // Báo thất bại cho LoginFrame để xử lý
                                registerCallback.accept(false);
                                logger.info("=== CALLBACK CALLED ===");
                            } else {
                                // Lỗi đăng nhập bình thường - hiển thị thông báo
                                JOptionPane.showMessageDialog(ServerSelectionDialog.this, 
                                    "Không thể kết nối tới server!\n\nChi tiết: " + errorMsg + 
                                    "\n\nVui lòng kiểm tra:\n" +
                                    "- Server đã được khởi động chưa?\n" +
                                    "- Địa chỉ và port có đúng không?\n" +
                                    "- Firewall có chặn kết nối không?", 
                                    "Lỗi kết nối", 
                                    JOptionPane.ERROR_MESSAGE);
                            }
                        });
                    }
                }).start();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn server!");
        }
    }

    public boolean isConnected() {
        return connected;
    }

    class ServerListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(
                list, value, index, isSelected, cellHasFocus);
            
            String text = value.toString();
            String[] parts = text.split(":");
            if (parts.length == 2) {
                label.setText("  🖥️  " + parts[0] + "   Port: " + parts[1]);
            }
            
            return label;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
