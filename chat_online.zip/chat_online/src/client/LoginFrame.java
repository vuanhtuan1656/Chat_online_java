/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package client;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Consumer;

/**
 *
 * @author Toan PC
 */
public class LoginFrame extends javax.swing.JFrame {
 private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton, exitButton;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LoginFrame.class.getName());

    /**
     * Creates new form LoginFrame
     */
    public LoginFrame() {
        initLogin();
    }
private void initLogin() {
        setTitle("Đăng nhập - Chat Application");
        setSize(450, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // Title
        JLabel titleLabel = new JLabel("ĐĂNG NHẬP HỆ THỐNG", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(51, 122, 183));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.weightx = 0.3;
        JLabel userLabel = new JLabel("Tên đăng nhập:");
        userLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        formPanel.add(userLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 13));
        formPanel.add(usernameField, gbc);

        // Password
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.weightx = 0.3;
        JLabel passLabel = new JLabel("Mật khẩu:");
        passLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        formPanel.add(passLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 13));
        formPanel.add(passwordField, gbc);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        registerButton = new JButton("Đăng ký");
        registerButton.setFont(new Font("Arial", Font.PLAIN, 13));
        registerButton.setBackground(new Color(92, 184, 92));
        registerButton.setForeground(Color.BLUE);
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(e -> showRegisterDialog("", "", ""));

        loginButton = new JButton("Đăng nhập");
        loginButton.setFont(new Font("Arial", Font.PLAIN, 13));
        loginButton.setBackground(new Color(51, 122, 183));
        loginButton.setForeground(Color.BLUE);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(e -> handleLogin());

        exitButton = new JButton("Thoát");
        exitButton.setFont(new Font("Arial", Font.PLAIN, 13));
        exitButton.setBackground(new Color(217, 83, 79));
        exitButton.setForeground(Color.BLUE);
        exitButton.setFocusPainted(false);
        exitButton.addActionListener(e -> System.exit(0));

        buttonPanel.add(registerButton);
        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Enter key listener
        passwordField.addActionListener(e -> handleLogin());
        
        setVisible(true);
    }

    /**
     * Hiển thị form đăng ký với thông tin mặc định (để giữ lại khi lỗi)
     */
    private void showRegisterDialog(String defaultUsername, String defaultPassword, String defaultFullName) {
        JDialog dialog = new JDialog(this, "Đăng ký tài khoản", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Tên đăng nhập:"), gbc);
        gbc.gridx = 1;
        JTextField regUsername = new JTextField(defaultUsername, 20);
        panel.add(regUsername, gbc);

        // Password
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Mật khẩu:"), gbc);
        gbc.gridx = 1;
        JPasswordField regPassword = new JPasswordField(defaultPassword, 20);
        panel.add(regPassword, gbc);

        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Xác nhận mật khẩu:"), gbc);
        gbc.gridx = 1;
        JPasswordField regConfirmPass = new JPasswordField(defaultPassword, 20);
        panel.add(regConfirmPass, gbc);

        // Full Name
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("Họ và tên:"), gbc);
        gbc.gridx = 1;
        JTextField regFullName = new JTextField(defaultFullName, 20);
        panel.add(regFullName, gbc);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton okBtn = new JButton("Đăng ký");
        JButton cancelBtn = new JButton("Hủy");

        okBtn.addActionListener(e -> {
            String username = regUsername.getText().trim();
            String password = new String(regPassword.getPassword());
            String confirmPass = new String(regConfirmPass.getPassword());
            String fullName = regFullName.getText().trim();

            if (username.isEmpty() || password.isEmpty() || fullName.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng điền đầy đủ thông tin!");
                return;
            }

            if (!password.equals(confirmPass)) {
                JOptionPane.showMessageDialog(dialog, "Mật khẩu xác nhận không khớp!");
                return;
            }

            // Đóng dialog trước
            dialog.dispose();
            
            // Thử register với callback
            attemptRegister(username, password, fullName);
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        btnPanel.add(okBtn);
        btnPanel.add(cancelBtn);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(btnPanel, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    /**
     * Thử register - nếu thất bại thì mở lại dialog với thông tin cũ
     */
    private void attemptRegister(String username, String password, String fullName) {
        // Tạo callback để nhận kết quả
        Consumer<Boolean> callback = success -> {
            logger.info("=== CALLBACK RECEIVED: success = " + success + " ===");
            
            // THAY ĐỔI: Đảm bảo chạy trên EDT
            SwingUtilities.invokeLater(() -> {
                logger.info("=== Running callback on EDT ===");
                
                if (success) {
                    // Thành công → ChatWindow đã mở, LoginFrame dispose
                    logger.info("Registration successful, disposing LoginFrame");
                    this.dispose();
                } else {
                    // Thất bại → hiện lỗi và mở lại form với thông tin cũ
                    logger.info("Registration failed, showing error and reopening dialog");
                    
                    JOptionPane.showMessageDialog(this,
                        "Tên đăng nhập đã tồn tại!\n\nVui lòng chọn tên đăng nhập khác.",
                        "Lỗi đăng ký",
                        JOptionPane.ERROR_MESSAGE);
                    
                    // Mở lại form đăng ký với thông tin đã nhập
                    showRegisterDialog(username, password, fullName);
                }
            });
        };
        
        logger.info("Opening ServerSelectionDialog for registration: " + username);
        // Mở ServerSelectionDialog với callback
        new ServerSelectionDialog(this, username, password, fullName, true, callback);
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên đăng nhập và mật khẩu!");
            return;
        }

        showServerSelection(username, password, null, false);
    }

    private void showServerSelection(String username, String password, String fullName, boolean isRegister) {
        ServerSelectionDialog dialog = new ServerSelectionDialog(this, username, password, fullName, isRegister, null);
        if (dialog.isConnected()) {
            this.dispose();
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> new LoginFrame());
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
