/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package client;
import model.Message;
import model.Message.MessageType;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.util.*;
import javax.imageio.ImageIO;
import model.FileTransfer;
/**
 *
 * @author Toan PC
 */
public class ChatWindow extends javax.swing.JFrame {
 private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String username;
    private String password;
    private String fullName;
    private boolean isRegister;
    
    private DefaultListModel<UserItem> userListModel;
    private JList<UserItem> userList;
    private JTextPane chatArea;
    private JTextField messageField;
    private JLabel statusLabel;
    private JComboBox<String> chatModeCombo;
    private Map<String, UserItem> users;
    private String currentChatUser = "ALL";
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ChatWindow.class.getName());

     private Map<String, Color> userColors;
    private Color[] colorPalette = {
        new Color(0, 102, 204),
        new Color(255, 102, 0),
        new Color(102, 51, 153),
        new Color(204, 0, 102),
        new Color(0, 153, 102),
        new Color(204, 102, 0),
        new Color(51, 153, 102),
        new Color(153, 51, 102)
    };
    private int colorIndex = 0;

 public ChatWindow(String host, int port, String username, String password, String fullName, boolean isRegister) throws IOException {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.isRegister = isRegister;
        this.users = new HashMap<>();
        this.userColors = new HashMap<>();
        
        initUI();
        connectToServer(host, port);
    }

    private void connectToServer(String host, int port) throws IOException {
        socket = new Socket(host, port);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

        if (statusLabel != null) {
            statusLabel.setText("🟢 Đã kết nối - " + host + ":" + port);
        }

        if (isRegister) {
            Message regMsg = new Message(MessageType.REGISTER, username, 
                username + "|" + password + "|" + fullName);
            out.println(regMsg.toString());
        }

        Message loginMsg = new Message(MessageType.LOGIN, username, 
            username + "|" + password);
        out.println(loginMsg.toString());

        new Thread(this::receiveMessages).start();
    }

    private Color getUserColor(String username) {
        if (!userColors.containsKey(username)) {
            userColors.put(username, colorPalette[colorIndex % colorPalette.length]);
            colorIndex++;
        }
        return userColors.get(username);
    }

    private void initUI() {
        setTitle("Chat Application - " + username);
        setSize(950, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(250, 0));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Người dùng"));

        userListModel = new DefaultListModel<>();
        userList = new JList<>(userListModel);
        userList.setCellRenderer(new UserListRenderer());
        userList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                UserItem selected = userList.getSelectedValue();
                if (selected != null) {
                    currentChatUser = selected.username;
                    chatModeCombo.setSelectedItem(selected.username.equals(username) ? 
                        "Nhóm (Tất cả)" : "Riêng tư: " + selected.fullName);
                }
            }
        });
        
        leftPanel.add(new JScrollPane(userList), BorderLayout.CENTER);

        JPanel rightPanel = new JPanel(new BorderLayout());

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.add(new JLabel("Chế độ chat:"));
        chatModeCombo = new JComboBox<>(new String[]{"Nhóm (Tất cả)"});
        chatModeCombo.setPreferredSize(new Dimension(250, 25));
        chatModeCombo.addActionListener(e -> {
            String selected = (String) chatModeCombo.getSelectedItem();
            if (selected.equals("Nhóm (Tất cả)")) {
                currentChatUser = "ALL";
                userList.clearSelection();
            }
        });
        topBar.add(chatModeCombo);
        rightPanel.add(topBar, BorderLayout.NORTH);

        chatArea = new JTextPane();
        chatArea.setEditable(false);
        chatArea.setBackground(new Color(245, 245, 245));
        JScrollPane chatScroll = new JScrollPane(chatArea);
        chatScroll.setBorder(BorderFactory.createTitledBorder("Tin nhắn"));
        rightPanel.add(chatScroll, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel toolPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 2));
        
        JButton fileButton = new JButton("📁 File");
        fileButton.setToolTipText("Gửi file (max 3MB)");
        fileButton.setMargin(new Insets(2, 5, 2, 5));
        fileButton.addActionListener(e -> sendFile());
        toolPanel.add(fileButton);
        
        JButton imageButton = new JButton("🖼️ Ảnh");
        imageButton.setToolTipText("Gửi ảnh (max 3MB)");
        imageButton.setMargin(new Insets(2, 5, 2, 5));
        imageButton.addActionListener(e -> sendImage());
        toolPanel.add(imageButton);
        
        toolPanel.add(new JSeparator(SwingConstants.VERTICAL));
        
        String[] emojis = {"😊", "😂", "❤️", "👍", "🎉", "😢", "😮", "🔥", "💯", "✨"};
        for (String emoji : emojis) {
            JButton btn = new JButton(emoji);
            btn.setMargin(new Insets(2, 5, 2, 5));
            btn.setBorderPainted(false);
            btn.addActionListener(e -> messageField.setText(messageField.getText() + emoji));
            toolPanel.add(btn);
        }

        JPanel inputPanel = new JPanel(new BorderLayout(5, 0));
        messageField = new JTextField();
        messageField.setFont(new Font("Arial", Font.PLAIN, 14));
        messageField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        messageField.addActionListener(e -> sendMessage());

        JButton sendButton = new JButton("Gửi ✈");
        sendButton.setBackground(new Color(0, 132, 255));
        sendButton.setForeground(Color.BLUE);
        sendButton.setFont(new Font("Arial", Font.BOLD, 13));
        sendButton.setFocusPainted(false);
        sendButton.addActionListener(e -> sendMessage());

        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        bottomPanel.add(toolPanel, BorderLayout.NORTH);
        bottomPanel.add(inputPanel, BorderLayout.CENTER);

        rightPanel.add(bottomPanel, BorderLayout.SOUTH);

        statusLabel = new JLabel("🟡 Đang kết nối...");
        statusLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(5, 10, 5, 5)
        ));
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 11));

        setLayout(new BorderLayout());
        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                disconnect();
            }
        });

        setVisible(true);
    }

    private void sendFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn file để gửi");
        
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            
            try {
                byte[] fileData = Files.readAllBytes(file.toPath());
                String receiver = currentChatUser.equals("ALL") ? null : currentChatUser;

                String error = FileTransfer.validate(file.getName(), "file", fileData);
                if (error != null) {
                    JOptionPane.showMessageDialog(this, error, "Lỗi gửi file", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                FileTransfer ft = new FileTransfer(file.getName(), "file", fileData, username, receiver);
                
                Message msg = new Message(
                    MessageType.FILE_TRANSFER,
                    username, receiver,
                    ft.getFileName() + "|" + ft.getFileSizeFormatted() + "|" + ft.getBase64Data()
                );
                
                out.println(msg.toString());
                // Người gửi không cần nút download → base64Data = null
                appendFileMessage(username, file.getName(), ft.getFileSizeFormatted(), true, !currentChatUser.equals("ALL"), null);
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Không thể đọc file!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void sendImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn ảnh để gửi");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Image files", "jpg", "jpeg", "png", "gif", "bmp"));
        
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            
            try {
                byte[] fileData = Files.readAllBytes(file.toPath());
                String receiver = currentChatUser.equals("ALL") ? null : currentChatUser;

                String error = FileTransfer.validate(file.getName(), "image", fileData);
                if (error != null) {
                    JOptionPane.showMessageDialog(this, error, "Lỗi gửi ảnh", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                FileTransfer ft = new FileTransfer(file.getName(), "image", fileData, username, receiver);
                
                Message msg = new Message(
                    MessageType.IMAGE_TRANSFER,
                    username, receiver,
                    ft.getFileName() + "|" + ft.getFileSizeFormatted() + "|" + ft.getBase64Data()
                );
                
                out.println(msg.toString());
                // Người gửi không cần nút download
                appendImageMessage(username, fileData, file.getName(), true);
                
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Không thể đọc ảnh!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void sendMessage() {
        String content = messageField.getText().trim();
        if (content.isEmpty()) return;

        Message msg;
        if (currentChatUser.equals("ALL")) {
            msg = new Message(MessageType.MESSAGE, username, content);
        } else {
            msg = new Message(MessageType.PRIVATE_MESSAGE, username, currentChatUser, content);
        }
        
        out.println(msg.toString());
        
        String timestamp = new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date());
        appendMessage(username, content, timestamp, !currentChatUser.equals("ALL"));
        
        messageField.setText("");
    }

    private void receiveMessages() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                processMessage(parseMessage(line));
            }
        } catch (IOException e) {
            appendSystemMessage("❌ Mất kết nối tới server!");
            statusLabel.setText("🔴 Mất kết nối");
        } catch (RuntimeException e) {
            // THAY ĐỔI: Lỗi register - đã xử lý rồi, không cần in stack trace
            logger.info("Registration error handled: " + e.getMessage());
        }
    }

    private Message parseMessage(String line) {
        String[] parts = line.split("\\|", 5);
        MessageType type = MessageType.valueOf(parts[0]);
        String sender = parts.length > 1 ? parts[1] : null;
        String receiver = parts.length > 2 && !parts[2].equals("null") ? parts[2] : null;
        String timestamp = parts.length > 3 ? parts[3] : null;
        String content = parts.length > 4 ? parts[4] : null;
        
        Message msg = new Message(type, sender, receiver, content);
        msg.setTimestamp(timestamp);
        return msg;
    }

    private void processMessage(Message msg) {
        switch (msg.getType()) {
            case SUCCESS:
                if (isRegister) {
                    appendSystemMessage("✅ Đăng ký thành công! Đang đăng nhập...");
                    isRegister = false;
                } else {
                    this.fullName = msg.getContent();
                    appendSystemMessage("✅ Đăng nhập thành công! Chào mừng " + fullName);
                }
                break;
            case ERROR:
                // THAY ĐỔI: Nếu là lỗi register, throw exception để ServerSelectionDialog catch
                if (isRegister) {
                    // Đóng kết nối
                    try {
                        if (socket != null) socket.close();
                    } catch (IOException e) {
                        // Ignore
                    }
                    // Đóng cửa sổ
                    dispose();
                    // Throw exception với message lỗi
                    throw new RuntimeException(msg.getContent());
                } else {
                    // Lỗi login bình thường - hiển thị dialog
                    JOptionPane.showMessageDialog(this, msg.getContent(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
                break;
            case USER_LIST:
                updateUserList(msg.getContent());
                break;
            case ONLINE:
                String[] onlineParts = msg.getContent().split(";");
                if (onlineParts.length >= 2) {
                    addOrUpdateUser(onlineParts[0], onlineParts[1], true);
                    appendSystemMessage("🟢 " + onlineParts[1] + " đã online");
                }
                break;
            case OFFLINE:
                UserItem user = users.get(msg.getContent());
                if (user != null) {
                    user.online = false;
                    if (userList != null) userList.repaint();
                    appendSystemMessage("⚫ " + user.fullName + " đã offline");
                }
                break;
            case MESSAGE:
                if (!msg.getSender().equals(username)) {
                    appendMessage(msg.getSender(), msg.getContent(), msg.getTimestamp(), false);
                }
                break;
            case PRIVATE_MESSAGE:
                if (!msg.getSender().equals(username)) {
                    appendMessage(msg.getSender(), msg.getContent(), msg.getTimestamp(), true);
                }
                break;
            case FILE_TRANSFER:
                String[] fileParts = msg.getContent().split("\\|", 3);
                if (fileParts.length >= 3) {
                    if (!msg.getSender().equals(username)) {
                        // Pass base64Data để có thể download
                        appendFileMessage(msg.getSender(), fileParts[0], fileParts[1], false, msg.getReceiver() != null, fileParts[2]);
                    }
                }
                break;
            case IMAGE_TRANSFER:
                String[] imgParts = msg.getContent().split("\\|", 3);
                if (imgParts.length >= 3) {
                    if (!msg.getSender().equals(username)) {
                        try {
                            byte[] imgData = Base64.getDecoder().decode(imgParts[2]);
                            appendImageMessage(msg.getSender(), imgData, imgParts[0], false);
                        } catch (Exception e) {
                            appendSystemMessage("❌ Không thể hiển thị ảnh");
                        }
                    }
                }
                break;
        }
    }

    private void updateUserList(String data) {
        String[] userEntries = data.split("##");
        for (String entry : userEntries) {
            if (entry.trim().isEmpty()) continue;
            String[] parts = entry.split(";");
            if (parts.length >= 3) {
                addOrUpdateUser(parts[0], parts[1], Boolean.parseBoolean(parts[2]));
            }
        }
    }

    private void addOrUpdateUser(String username, String fullName, boolean online) {
        SwingUtilities.invokeLater(() -> {
            if (userListModel == null || chatModeCombo == null) return;
            
            UserItem item = users.get(username);
            if (item == null) {
                item = new UserItem(username, fullName, online);
                users.put(username, item);
                
                if (username.equals(this.username)) {
                    userListModel.add(0, item);
                } else {
                    userListModel.addElement(item);
                    chatModeCombo.addItem("Riêng tư: " + fullName);
                }
            } else {
                item.online = online;
                if (userList != null) userList.repaint();
            }
        });
    }

    private void appendMessage(String sender, String content, String timestamp, boolean isPrivate) {
        SwingUtilities.invokeLater(() -> {
            try {
                if (chatArea == null) return;
                
                StyledDocument doc = chatArea.getStyledDocument();
                boolean isSelf = sender.equals(username);
                Color senderColor = isSelf ? new Color(0, 128, 0) : getUserColor(sender);
                
                doc.insertString(doc.getLength(), "\n", null);
                
                if (isPrivate) {
                    Style privateStyle = chatArea.addStyle("Private", null);
                    StyleConstants.setBackground(privateStyle, new Color(255, 245, 220));
                    StyleConstants.setForeground(privateStyle, new Color(204, 102, 0));
                    StyleConstants.setBold(privateStyle, true);
                    StyleConstants.setFontSize(privateStyle, 11);
                    doc.insertString(doc.getLength(), " 🔒 RIÊNG TƯ ", privateStyle);
                    doc.insertString(doc.getLength(), "\n", null);
                }
                
                Style senderStyle = chatArea.addStyle("Sender" + sender, null);
                StyleConstants.setBold(senderStyle, true);
                StyleConstants.setForeground(senderStyle, senderColor);
                StyleConstants.setFontSize(senderStyle, 13);
                
                UserItem user = users.get(sender);
                String displayName = user != null ? user.fullName : sender;
                doc.insertString(doc.getLength(), displayName, senderStyle);
                
                Style timeStyle = chatArea.addStyle("Time", null);
                StyleConstants.setForeground(timeStyle, new Color(128, 128, 128));
                StyleConstants.setFontSize(timeStyle, 10);
                doc.insertString(doc.getLength(), "  " + timestamp, timeStyle);
                
                Style contentStyle = chatArea.addStyle("Content", null);
                StyleConstants.setForeground(contentStyle, Color.BLACK);
                StyleConstants.setFontSize(contentStyle, 13);
                if (isSelf) {
                    StyleConstants.setBackground(contentStyle, new Color(220, 248, 220));
                } else {
                    StyleConstants.setBackground(contentStyle, Color.WHITE);
                }
                
                doc.insertString(doc.getLength(), "\n  " + content + "\n", contentStyle);
                chatArea.setCaretPosition(doc.getLength());
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        });
    }

    // base64Data = null nếu người gửi (không cần download), có giá trị nếu người nhận
    private void appendFileMessage(String sender, String fileName, String fileSize, boolean isSelf, boolean isPrivate, String base64Data) {
        SwingUtilities.invokeLater(() -> {
            try {
                if (chatArea == null) return;
                
                StyledDocument doc = chatArea.getStyledDocument();
                doc.insertString(doc.getLength(), "\n", null);
                
                Color senderColor = isSelf ? new Color(0, 128, 0) : getUserColor(sender);
                
                Style senderStyle = chatArea.addStyle("FileSender", null);
                StyleConstants.setBold(senderStyle, true);
                StyleConstants.setForeground(senderStyle, senderColor);
                
                UserItem user = users.get(sender);
                String displayName = user != null ? user.fullName : sender;
                doc.insertString(doc.getLength(), displayName + " ", senderStyle);
                
                Style fileStyle = chatArea.addStyle("File", null);
                StyleConstants.setForeground(fileStyle, new Color(51, 102, 153));
                StyleConstants.setBackground(fileStyle, new Color(230, 240, 255));
                doc.insertString(doc.getLength(), "đã gửi file:\n", fileStyle);
                
                Style fileNameStyle = chatArea.addStyle("FileName", null);
                StyleConstants.setBold(fileNameStyle, true);
                StyleConstants.setForeground(fileNameStyle, new Color(0, 51, 102));
                doc.insertString(doc.getLength(), "  📎 " + fileName + " (" + fileSize + ")\n", fileNameStyle);

                // Chỉ show nút "Tải về" cho người nhận
              if (!isSelf && base64Data != null) {
    chatArea.setCaretPosition(doc.getLength());  // Đặt con trỏ ở cuối
    chatArea.insertComponent(createDownloadButton(fileName, base64Data));  // Sửa ở đây
    doc.insertString(doc.getLength(), "\n", null);
}
                
                chatArea.setCaretPosition(doc.getLength());
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        });
    }

    private void appendImageMessage(String sender, byte[] imageData, String fileName, boolean isSelf) {
        SwingUtilities.invokeLater(() -> {
            try {
                if (chatArea == null) return;
                
                StyledDocument doc = chatArea.getStyledDocument();
                doc.insertString(doc.getLength(), "\n", null);
                
                Color senderColor = isSelf ? new Color(0, 128, 0) : getUserColor(sender);
                
                Style senderStyle = chatArea.addStyle("ImgSender", null);
                StyleConstants.setBold(senderStyle, true);
                StyleConstants.setForeground(senderStyle, senderColor);
                
                UserItem user = users.get(sender);
                String displayName = user != null ? user.fullName : sender;
                doc.insertString(doc.getLength(), displayName + " đã gửi ảnh:\n", senderStyle);
                
                ByteArrayInputStream bis = new ByteArrayInputStream(imageData);
                BufferedImage img = ImageIO.read(bis);
                
                if (img != null) {
                    int maxWidth = 300;
                    int maxHeight = 300;
                    int width = img.getWidth();
                    int height = img.getHeight();
                    
                    if (width > maxWidth || height > maxHeight) {
                        double scale = Math.min((double) maxWidth / width, (double) maxHeight / height);
                        width = (int) (width * scale);
                        height = (int) (height * scale);
                        
                        Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                        ImageIcon icon = new ImageIcon(scaledImg);
                        
                        Style imgStyle = chatArea.addStyle("Image", null);
                        StyleConstants.setIcon(imgStyle, icon);
                        doc.insertString(doc.getLength(), " ", imgStyle);
                    } else {
                        ImageIcon icon = new ImageIcon(img);
                        Style imgStyle = chatArea.addStyle("Image", null);
                        StyleConstants.setIcon(imgStyle, icon);
                        doc.insertString(doc.getLength(), " ", imgStyle);
                    }
                }
                
                doc.insertString(doc.getLength(), "\n", null);

                // Chỉ show nút "Tải về" cho người nhận
               if (!isSelf) {
    String base64 = Base64.getEncoder().encodeToString(imageData);
    chatArea.setCaretPosition(doc.getLength());  // Đặt con trỏ ở cuối
    chatArea.insertComponent(createDownloadButton(fileName, base64));  // Sửa ở đây
    doc.insertString(doc.getLength(), "\n", null);
}
                
                chatArea.setCaretPosition(doc.getLength());
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Tạo nút "Tải về" — click sẽ gọi saveFile()
     */
    private JButton createDownloadButton(String fileName, String base64Data) {
        JButton downloadBtn = new JButton("⬇️ Tải về");
        downloadBtn.setBackground(new Color(34, 139, 34));
        downloadBtn.setForeground(Color.WHITE);
        downloadBtn.setFont(new Font("Arial", Font.BOLD, 12));
        downloadBtn.setFocusPainted(false);
        downloadBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 100, 0)),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        downloadBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        downloadBtn.addActionListener(e -> saveFile(fileName, base64Data));
        return downloadBtn;
    }

    /**
     * Mở SaveDialog và lưu file về máy
     */
    private void saveFile(String fileName, String base64Data) {
        JFileChooser saveChooser = new JFileChooser();
        saveChooser.setDialogTitle("Chọn nơi lưu file");
        saveChooser.setSelectedFile(new File(fileName));

        if (saveChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File saveFile = saveChooser.getSelectedFile();
            try {
                byte[] data = Base64.getDecoder().decode(base64Data);
                Files.write(saveFile.toPath(), data);
                JOptionPane.showMessageDialog(this,
                    "✅ Đã lưu file thành công!\n📁 " + saveFile.getAbsolutePath(),
                    "Lưu thành công",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "❌ Không thể lưu file!\n" + e.getMessage(),
                    "Lỗi lưu file",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void appendSystemMessage(String message) {
        SwingUtilities.invokeLater(() -> {
            try {
                if (chatArea == null) return;
                
                StyledDocument doc = chatArea.getStyledDocument();
                Style style = chatArea.addStyle("System", null);
                StyleConstants.setForeground(style, new Color(120, 120, 120));
                StyleConstants.setItalic(style, true);
                StyleConstants.setAlignment(style, StyleConstants.ALIGN_CENTER);
                StyleConstants.setFontSize(style, 11);
                
                doc.insertString(doc.getLength(), "\n─── " + message + " ───\n", style);
                chatArea.setCaretPosition(doc.getLength());
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        });
    }

    private void disconnect() {
        try {
            if (out != null) {
                Message logoutMsg = new Message(MessageType.LOGOUT, username, "");
                out.println(logoutMsg.toString());
            }
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class UserItem {
        String username;
        String fullName;
        boolean online;

        UserItem(String username, String fullName, boolean online) {
            this.username = username;
            this.fullName = fullName;
            this.online = online;
        }

        @Override
        public String toString() {
            return fullName;
        }
    }

    class UserListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(
                list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof UserItem) {
                UserItem item = (UserItem) value;
                // THAY ĐỔI: Dùng ● và ○ thay vì emoji
                String status = item.online ? "●" : "○";
                Color statusColor = item.online ? new Color(0, 200, 0) : Color.GRAY;
                
                label.setText("  " + status + "  " + item.fullName);
                label.setFont(new Font("Arial", Font.PLAIN, 13));
                
                // Tô màu cho status icon
                if (!isSelected && item.online) {
                    label.setForeground(statusColor);
                }
                
                if (!isSelected) {
                    if (item.username.equals(username)) {
                        label.setBackground(new Color(230, 247, 255));
                    }
                }
            }
            
            return label;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
