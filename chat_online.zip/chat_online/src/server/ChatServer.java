/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package server;


import database.UserDatabase;
import model.Message;
import model.Message.MessageType;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.List;
/**
 *
 * @author Toan PC
 */
public class ChatServer extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ChatServer.class.getName());
 private JTextField portField;
    private JButton startButton;
    private JButton stopButton;
    private JTextArea logArea;
    private JTable clientTable;
    private DefaultTableModel tableModel;
    private ServerSocket serverSocket;
    private List<ClientHandler> clients;
    private UserDatabase database;
    private boolean isRunning;
    private int stt = 1;
    /**
     * Creates new form server
     */
    public ChatServer() {
        clients = new ArrayList<>();
        database = new UserDatabase();
        initCustomComponents();
        startServer();
    }
     private void  initCustomComponents() {
        setTitle("Chat Server - Configuration");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Port"));
        portField = new JTextField("3000", 10);
        portField.setEditable(false);
        topPanel.add(portField);

        startButton = new JButton("Start");
        startButton.setEnabled(false);
        startButton.addActionListener(e -> startServer());
        topPanel.add(startButton);

        stopButton = new JButton("Stop");
        stopButton.setEnabled(false);
        stopButton.addActionListener(e -> stopServer());
        topPanel.add(stopButton);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createTitledBorder("Server Logs"));
        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        centerPanel.add(logScroll, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(BorderFactory.createTitledBorder("Connected Clients"));
        String[] columns = {"STT", "IP Address", "Port", "Username", "Full Name"};
        tableModel = new DefaultTableModel(columns, 0);
        clientTable = new JTable(tableModel);
        JScrollPane tableScroll = new JScrollPane(clientTable);
        bottomPanel.add(tableScroll, BorderLayout.CENTER);

        setLayout(new BorderLayout());
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void log(String message) {
        SwingUtilities.invokeLater(() -> {
            logArea.append("[" + new java.text.SimpleDateFormat("HH:mm:ss").format(new Date()) + "] " + message + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    private void startServer() {
        if (isRunning) {
            log("Server is already running!");
            return;
        }

        SwingUtilities.invokeLater(() -> {
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            portField.setEditable(false);
        });

        new Thread(() -> {
            try {
                int port = Integer.parseInt(portField.getText());
                serverSocket = new ServerSocket(port);
                isRunning = true;
                log("Server started successfully");
                log("Listening on port " + port);
                log("Waiting for clients...");

                while (isRunning) {
                    try {
                        Socket clientSocket = serverSocket.accept();
                        log("New connection from " + clientSocket.getInetAddress());
                        ClientHandler handler = new ClientHandler(clientSocket);
                        clients.add(handler);
                        new Thread(handler).start();
                    } catch (SocketException e) {
                        if (!isRunning) break;
                    }
                }
            } catch (IOException e) {
                log("ERROR: " + e.getMessage());
                SwingUtilities.invokeLater(() -> {
                    startButton.setEnabled(true);
                    stopButton.setEnabled(false);
                    portField.setEditable(true);
                });
                isRunning = false;
            }
        }).start();
    }

    private void stopServer() {
        try {
            isRunning = false;
            for (ClientHandler client : clients) {
                client.close();
            }
            clients.clear();
            if (serverSocket != null) {
                serverSocket.close();
            }
            log("Server stopped");
            tableModel.setRowCount(0);
            stt = 1;

            SwingUtilities.invokeLater(() -> {
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                portField.setEditable(true);
            });
        } catch (IOException e) {
            log("Error stopping server: " + e.getMessage());
        }
    }

    private synchronized void broadcast(Message message, ClientHandler sender) {
        for (ClientHandler client : clients) {
            if (client.isAuthenticated() && client != sender) {
                client.sendMessage(message);
            }
        }
    }

    private synchronized void sendToUser(String username, Message message) {
        for (ClientHandler client : clients) {
            if (client.isAuthenticated() && client.getUsername().equals(username)) {
                client.sendMessage(message);
                break;
            }
        }
    }

    private void addClientToTable(String ip, int port, String username, String fullName) {
        SwingUtilities.invokeLater(() -> {
            tableModel.addRow(new Object[]{stt++, ip, port, username, fullName});
        });
    }

    private void removeClientFromTable(String username) {
        SwingUtilities.invokeLater(() -> {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (tableModel.getValueAt(i, 3).equals(username)) {
                    tableModel.removeRow(i);
                    for (int j = 0; j < tableModel.getRowCount(); j++) {
                        tableModel.setValueAt(j + 1, j, 0);
                    }
                    stt = tableModel.getRowCount() + 1;
                    break;
                }
            }
        });
    }

    class ClientHandler implements Runnable {
        private Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private String username;
        private boolean authenticated = false;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public boolean isAuthenticated() {
            return authenticated;
        }

        public String getUsername() {
            return username;
        }

        public void sendMessage(Message message) {
            if (out != null) {
                out.println(message.toString());
            }
        }

        public void close() {
            try {
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

                String line;
                while ((line = in.readLine()) != null) {
                    processMessage(parseMessage(line));
                }
            } catch (IOException e) {
                log("Client disconnected: " + (username != null ? username : "Unknown"));
            } finally {
                handleDisconnect();
            }
        }

        private Message parseMessage(String line) {
            String[] parts = line.split("\\|", 5);
            MessageType type = MessageType.valueOf(parts[0]);
            String sender = parts.length > 1 ? parts[1] : null;
            String receiver = parts.length > 2 && !parts[2].equals("null") ? parts[2] : null;
            String timestamp = parts.length > 3 ? parts[3] : null;
            String content = parts.length > 4 ? parts[4] : null;
            
            return new Message(type, sender, receiver, content);
        }

        private void processMessage(Message msg) {
            switch (msg.getType()) {
                case REGISTER:
                    handleRegister(msg);
                    break;
                case LOGIN:
                    handleLogin(msg);
                    break;
                case MESSAGE:
                    handleGroupMessage(msg);
                    break;
                case PRIVATE_MESSAGE:
                    handlePrivateMessage(msg);
                    break;
                case FILE_TRANSFER:
                    handleFileTransfer(msg);
                    break;
                case IMAGE_TRANSFER:
                    handleImageTransfer(msg);
                    break;
                case LOGOUT:
                    handleDisconnect();
                    break;
            }
        }

        private void handleRegister(Message msg) {
            String[] parts = msg.getContent().split("\\|");
            String username = parts[0];
            String password = parts[1];
            String fullName = parts[2];

            if (database.registerUser(username, password, fullName)) {
                log("New user registered: " + username);
                sendMessage(new Message(MessageType.SUCCESS, "SERVER", "Đăng ký thành công!"));
            } else {
                sendMessage(new Message(MessageType.ERROR, "SERVER", "Tên đăng nhập đã tồn tại!"));
            }
        }

        private void handleLogin(Message msg) {
            String[] parts = msg.getContent().split("\\|");
            String username = parts[0];
            String password = parts[1];

            User user = database.authenticateUser(username, password);
            if (user != null) {
                this.username = username;
                this.authenticated = true;
                database.setUserOnline(username, true);

                String ip = socket.getInetAddress().getHostAddress();
                int port = socket.getPort();
                addClientToTable(ip, port, username, user.getFullName());
                log("User logged in: " + username + " (" + user.getFullName() + ")");

                // Send success to client
                sendMessage(new Message(MessageType.SUCCESS, "SERVER", user.getFullName()));

                // Send online users list
                // Dùng "##" thay "| " để không xung đột với delimiter của Message protocol
                List<User> users = database.getAllUsers();
                StringBuilder userList = new StringBuilder();
                for (User u : users) {
                    if (userList.length() > 0) {
                        userList.append("##");
                    }
                    userList.append(u.getUsername()).append(";")
                           .append(u.getFullName()).append(";")
                           .append(u.isOnline());
                }
                Message usersMsg = new Message(MessageType.USER_LIST, "SERVER", userList.toString());
                sendMessage(usersMsg);

                // Notify others
                Message onlineMsg = new Message(MessageType.ONLINE, username, username + ";" + user.getFullName());
                broadcast(onlineMsg, this);
            } else {
                sendMessage(new Message(MessageType.ERROR, "SERVER", "Sai tên đăng nhập hoặc mật khẩu!"));
            }
        }

        private void handleGroupMessage(Message msg) {
            log("Group message from " + msg.getSender() + ": " + msg.getContent());
            broadcast(msg, this);
        }

        private void handlePrivateMessage(Message msg) {
            log("Private message from " + msg.getSender() + " to " + msg.getReceiver());
            sendToUser(msg.getReceiver(), msg);
        }

        private void handleFileTransfer(Message msg) {
            String fileName = msg.getContent().split("\\|")[0];
            log("File transfer from " + msg.getSender() + ": " + fileName);
            
            if (msg.getReceiver() == null) {
                broadcast(msg, this);
            } else {
                sendToUser(msg.getReceiver(), msg);
            }
        }

        private void handleImageTransfer(Message msg) {
            String fileName = msg.getContent().split("\\|")[0];
            log("Image transfer from " + msg.getSender() + ": " + fileName);
            
            if (msg.getReceiver() == null) {
                broadcast(msg, this);
            } else {
                sendToUser(msg.getReceiver(), msg);
            }
        }

        private void handleDisconnect() {
            if (authenticated && username != null) {
                database.setUserOnline(username, false);
                removeClientFromTable(username);
                Message offlineMsg = new Message(MessageType.OFFLINE, username, username);
                broadcast(offlineMsg, this);
                log("User disconnected: " + username);
            }
            clients.remove(this);
            close();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatServer().setVisible(true));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
