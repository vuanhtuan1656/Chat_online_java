/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Toan PC
 */

public class FileTransfer implements Serializable {
    private static final long serialVersionUID = 1L;

    // Giới hạn tối đa 3MB
    public static final long MAX_FILE_SIZE = 3 * 1024 * 1024; // 3MB in bytes

    // Các extension image hợp lệ
    private static final Set<String> VALID_IMAGE_EXTENSIONS = new HashSet<>(
        Arrays.asList(".jpg", ".jpeg", ".png", ".gif", ".bmp")
    );

    // Các MIME type image hợp lệ (để double-check)
    private static final Set<String> VALID_IMAGE_MIME_TYPES = new HashSet<>(
        Arrays.asList("image/jpeg", "image/png", "image/gif", "image/bmp")
    );

    private String fileName;
    private String fileType; // image, document, etc.
    private long fileSize;
    private String base64Data;
    private String sender;
    private String receiver;

    /**
     * Constructor có validation.
     * Ném IllegalArgumentException nếu file không hợp lệ.
     */
    public FileTransfer(String fileName, String fileType, byte[] data, String sender, String receiver) {
        // Validate trước khi tạo object
        String error = validate(fileName, fileType, data);
        if (error != null) {
            throw new IllegalArgumentException(error);
        }

        this.fileName = fileName;
        this.fileType = fileType;
        this.fileSize = data.length;
        this.base64Data = Base64.getEncoder().encodeToString(data);
        this.sender = sender;
        this.receiver = receiver;
    }

    /**
     * Validate file trước khi gửi.
     * @return null nếu hợp lệ, String error message nếu không hợp lệ.
     */
    public static String validate(String fileName, String fileType, byte[] data) {
        // Kiểm tra file rỗng
        if (data == null || data.length == 0) {
            return "Lỗi: File rỗng! Vui lòng chọn file có dữ liệu.";
        }

        // Kiểm tra size > 3MB
        if (data.length > MAX_FILE_SIZE) {
            long sizeMB = data.length / (1024 * 1024);
            long sizeKB = (data.length % (1024 * 1024)) / 1024;
            return "Lỗi: File quá lớn (" + sizeMB + "MB " + sizeKB + "KB)! "
                 + "Giới hạn tối đa là 3MB.";
        }

        // Nếu fileType là image → kiểm tra extension và mime type
        if ("image".equalsIgnoreCase(fileType)) {
            // Kiểm tra extension
            String extension = getExtension(fileName);
            if (!VALID_IMAGE_EXTENSIONS.contains(extension.toLowerCase())) {
                return "Lỗi: Định dạng file không hợp lệ (\"" + extension + "\")! "
                     + "Chỉ cho phép các file ảnh: .jpg, .jpeg, .png, .gif, .bmp.";
            }

            // Kiểm tra magic bytes của file ảnh
            String magicError = validateImageMagicBytes(data, fileName);
            if (magicError != null) {
                return magicError;
            }
        }

        return null; // hợp lệ
    }

    /**
     * Kiểm tra magic bytes để đảm bảo file thực sự là ảnh.
     * Tránh trường hợp đổi tên file thành .jpg nhưng bên trong không phải ảnh.
     */
    private static String validateImageMagicBytes(byte[] data, String fileName) {
        if (data.length < 4) {
            return "Lỗi: File quá nhỏ, không phải file ảnh hợp lệ.";
        }

        boolean isValidImage = false;

        // JPEG: starts with FF D8 FF
        if (data[0] == (byte) 0xFF && data[1] == (byte) 0xD8 && data[2] == (byte) 0xFF) {
            isValidImage = true;
        }
        // PNG: starts with 89 50 4E 47
        else if (data[0] == (byte) 0x89 && data[1] == (byte) 0x50
              && data[2] == (byte) 0x4E && data[3] == (byte) 0x47) {
            isValidImage = true;
        }
        // GIF: starts with "GIF87a" or "GIF89a"
        else if (data[0] == (byte) 0x47 && data[1] == (byte) 0x49 && data[2] == (byte) 0x46) {
            isValidImage = true;
        }
        // BMP: starts with "BM"
        else if (data[0] == (byte) 0x42 && data[1] == (byte) 0x4D) {
            isValidImage = true;
        }

        if (!isValidImage) {
            return "Lỗi: File \"" + fileName + "\" không phải file ảnh hợp lệ! "
                 + "Nội dung file không khớp với định dạng ảnh.";
        }

        return null;
    }

    /**
     * Lấy extension của file (bao gồm dấu chấm, ví dụ: ".jpg")
     */
    private static String getExtension(String fileName) {
        if (fileName == null || !fileName.contains(".")) {
            return "";
        }
        return fileName.substring(fileName.lastIndexOf('.'));
    }

    // ===================== Getters =====================

    public String getFileName() {
        return fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public byte[] getData() {
        return Base64.getDecoder().decode(base64Data);
    }

    public String getBase64Data() {
        return base64Data;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    /**
     * Format file size  (B, KB, MB)
     */
    public String getFileSizeFormatted() {
        if (fileSize < 1024) return fileSize + " B";
        if (fileSize < 1024 * 1024) return String.format("%.2f KB", fileSize / 1024.0);
        return String.format("%.2f MB", fileSize / (1024.0 * 1024.0));
    }

    /**
     * Kiểm tra file có phải ảnh không dựa vào extension
     */
    public boolean isImage() {
        String extension = getExtension(fileName);
        return VALID_IMAGE_EXTENSIONS.contains(extension.toLowerCase());
    }

}

