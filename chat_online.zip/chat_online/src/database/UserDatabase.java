/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;
import model.User;
import java.io.*;
import java.sql.*;
import java.util.*;
import model.User;
/**
 *
 * @author Toan PC
 */
public class UserDatabase extends DataAccessHelper {
    public UserDatabase() {
        // Không cần loadUsers nữa, mỗi method sẽ connect/close tự
    }

    // ===================== REGISTER =====================

    public synchronized boolean registerUser(String username, String password, String fullName) {
        getConnect();
        try {
            // Kiểm tra username đã tồn tại chưa
            String checkSql = "SELECT COUNT(*) AS cnt FROM dbo.TaiKhoan WHERE username = ?";
            PreparedStatement checkStmt = con.prepareStatement(checkSql);
            checkStmt.setString(1, username);
            ResultSet checkRs = checkStmt.executeQuery();

            if (checkRs.next() && checkRs.getInt("cnt") > 0) {
                checkStmt.close();
                return false; // username đã tồn tại
            }
            checkStmt.close();

            // Insert user mới
            String insertSql = "INSERT INTO dbo.TaiKhoan (username, password, fullName, isOnline) VALUES (?, ?, ?, 0)";
            PreparedStatement insertStmt = con.prepareStatement(insertSql);
            insertStmt.setString(1, username);
            insertStmt.setString(2, password);
            insertStmt.setString(3, fullName);
            insertStmt.executeUpdate();
            insertStmt.close();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            getClose();
        }
    }

    // 

    public synchronized User authenticateUser(String username, String password) {
        getConnect();
        try {
            String sql = "SELECT username, password, fullName, isOnline FROM dbo.TaiKhoan WHERE username = ? AND password = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullName")
                );
                user.setOnline(rs.getBoolean("isOnline"));
                stmt.close();
                return user;
            }

            stmt.close();
            return null; // sai username hoặc password
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            getClose();
        }
    }

    // ===================== CHECK USER EXISTS =====================

    public synchronized boolean userExists(String username) {
        getConnect();
        try {
            String sql = "SELECT COUNT(*) AS cnt FROM dbo.TaiKhoan WHERE username = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            boolean exists = rs.next() && rs.getInt("cnt") > 0;
            stmt.close();
            return exists;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            getClose();
        }
    }

    // ===================== SET ONLINE STATUS =====================

    public synchronized void setUserOnline(String username, boolean online) {
        getConnect();
        try {
            String sql = "UPDATE dbo.TaiKhoan SET isOnline = ? WHERE username = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setBoolean(1, online);
            stmt.setString(2, username);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            getClose();
        }
    }

    // ===================== GET ALL USERS =====================

    public synchronized List<User> getAllUsers() {
        getConnect();
        List<User> users = new ArrayList<>();
        try {
            String sql = "SELECT username, password, fullName, isOnline FROM dbo.TaiKhoan";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                User user = new User(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullName")
                );
                user.setOnline(rs.getBoolean("isOnline"));
                users.add(user);
            }

            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            getClose();
        }
        return users;
    }

    // ===================== GET SINGLE USER =====================

    public synchronized User getUser(String username) {
        getConnect();
        try {
            String sql = "SELECT username, password, fullName, isOnline FROM dbo.TaiKhoan WHERE username = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullName")
                );
                user.setOnline(rs.getBoolean("isOnline"));
                stmt.close();
                return user;
            }

            stmt.close();
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            getClose();
        }
    }
}
