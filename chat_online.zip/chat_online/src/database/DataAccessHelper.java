/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Toan PC
 */
public class DataAccessHelper {
     protected Connection con;

    public void getConnect() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://DESKTOP-V0AMEPA\\SQLEXPRESS:1433;"
                    + "databaseName=chatonline;"
                    + "encrypt=false;";
            con = DriverManager.getConnection(connectionUrl, "sa", "123456");
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException("Không thể kết nối tới CSDL: " + ex.getMessage());
        }
    }

    public void getClose() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
